/* =========================================================
   CyberTrace — Geospatial Intelligence Investigator
   Project by: Syeda Zoya
   Vanilla JS · Leaflet · Nominatim · Wikimedia Commons
   ========================================================= */

(function () {
  'use strict';

  /* =====================================================
     CONSTANTS & STORAGE KEYS
     ===================================================== */
  const STORAGE = {
    CASES: 'cybertrace_cases',
    EVIDENCE: 'cybertrace_evidence',
    HISTORY: 'cybertrace_search_history',
    SAVED_LOCATIONS: 'cybertrace_saved_locations',
    SETTINGS: 'cybertrace_settings'
  };

  const NOMINATIM_BASE = 'https://nominatim.openstreetmap.org';
  const WIKIMEDIA_COMMONS_API = 'https://commons.wikimedia.org/w/api.php';
  const DEFAULT_VIEW = { lat: 20.0, lng: 0.0, zoom: 2 };
  const NOMINATIM_COOLDOWN_MS = 1100;

  /* =====================================================
     STATE
     ===================================================== */
  const state = {
    currentLocation: null,
    searchResults: [],
    activeView: 'dashboard',
    dashboardMap: null,
    geospatialMap: null,
    fullMap: null,
    dashboardMarker: null,
    geospatialMarker: null,
    fullMarker: null,
    lastSearchQuery: '',
    searchInProgress: false,
    lastNominatimAt: 0
  };

  /* =====================================================
     STORAGE HELPERS
     ===================================================== */
  function loadJSON(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (err) {
      console.warn('Storage read failed for', key, err);
      return fallback;
    }
  }

  function saveJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (err) {
      console.warn('Storage write failed for', key, err);
    }
  }

  const getCases = () => loadJSON(STORAGE.CASES, []);
  const setCases = (v) => saveJSON(STORAGE.CASES, v);
  const getEvidence = () => loadJSON(STORAGE.EVIDENCE, []);
  const setEvidence = (v) => saveJSON(STORAGE.EVIDENCE, v);
  const getHistory = () => loadJSON(STORAGE.HISTORY, []);
  const setHistory = (v) => saveJSON(STORAGE.HISTORY, v);
  const getSavedLocations = () => loadJSON(STORAGE.SAVED_LOCATIONS, []);
  const setSavedLocations = (v) => saveJSON(STORAGE.SAVED_LOCATIONS, v);

  /* =====================================================
     UTILITY HELPERS
     ===================================================== */
  function uid(prefix) {
    return (
      (prefix || 'id') +
      '-' +
      Date.now().toString(36) +
      '-' +
      Math.random().toString(36).slice(2, 7)
    ).toUpperCase();
  }

  const nowISO = () => new Date().toISOString();

  function formatDateTime(iso) {
    if (!iso) return '—';
    try {
      return new Date(iso).toLocaleString();
    } catch {
      return iso;
    }
  }

  function escapeHTML(str) {
    if (str == null) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function truncate(str, len) {
    if (!str) return '';
    return str.length > len ? str.slice(0, len - 1) + '…' : str;
  }

  const qs = (sel, root) => (root || document).querySelector(sel);
  const qsa = (sel, root) =>
    Array.from((root || document).querySelectorAll(sel));

  function debounce(fn, wait) {
    let t;
    return function (...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  }

  function safeNum(v) {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  }

  /* =====================================================
     TOAST
     ===================================================== */
  function toast(message, type) {
    const el = document.createElement('div');
    el.className = 'toast ' + (type || 'info');
    el.textContent = message;
    el.style.cssText = `
      position: fixed; bottom: 20px; right: 20px; z-index: 9999;
      background: ${
        type === 'error' ? '#2d1e1e' : type === 'success' ? '#22302a' : '#2c1f29'
      };
      color: ${
        type === 'error' ? '#fca5a5' : type === 'success' ? '#c9f2e3' : '#fde4ec'
      };
      border: 1px solid ${
        type === 'error' ? '#7f1d1d' : type === 'success' ? '#7ed9b8' : '#f7a8c4'
      };
      padding: 10px 16px; border-radius: 10px; font-size: 0.85rem;
      box-shadow: 0 8px 24px rgba(40,20,35,0.6);
      transition: opacity 0.3s; max-width: 320px;
    `;
    document.body.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 300);
    }, 2800);
  }

  /* =====================================================
     MAPS
     ===================================================== */
  function makeBaseMap(el) {
    const m = L.map(el).setView([DEFAULT_VIEW.lat, DEFAULT_VIEW.lng], DEFAULT_VIEW.zoom);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution:
        '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19
    }).addTo(m);
    return m;
  }

  function initMaps() {
    const dashEl = qs('#map');
    const geoEl = qs('#mapGeospatial');
    const fullEl = qs('#mapFull');

    if (dashEl && !state.dashboardMap) state.dashboardMap = makeBaseMap(dashEl);
    if (geoEl && !state.geospatialMap) state.geospatialMap = makeBaseMap(geoEl);
    if (fullEl && !state.fullMap) state.fullMap = makeBaseMap(fullEl);
  }

  function setMarkerOnMap(mapRef, markerRef, location, zoom) {
    if (!mapRef || !location) return markerRef;
    if (markerRef) mapRef.removeLayer(markerRef);
    const marker = L.marker([location.lat, location.lng])
      .addTo(mapRef)
      .bindPopup(
        `<b>${escapeHTML(location.name || 'Location')}</b><br>${escapeHTML(
          location.address || ''
        )}`
      )
      .openPopup();
    mapRef.setView([location.lat, location.lng], zoom || 13);
    return marker;
  }

  function updateMapMarker(location) {
    if (!location || location.lat == null || location.lng == null) return;

    state.dashboardMarker = setMarkerOnMap(
      state.dashboardMap,
      state.dashboardMarker,
      location,
      13
    );
    state.geospatialMarker = setMarkerOnMap(
      state.geospatialMap,
      state.geospatialMarker,
      location,
      13
    );
    state.fullMarker = setMarkerOnMap(
      state.fullMap,
      state.fullMarker,
      location,
      13
    );

    const coordText = `${safeNum(location.lat).toFixed(5)}, ${safeNum(
      location.lng
    ).toFixed(5)}`;
    ['#coordLatLng', '#coordLatLngGeo', '#coordLatLngFull'].forEach((sel) => {
      const el = qs(sel);
      if (el) el.innerHTML = `<i class="fas fa-map-pin"></i> ${coordText}`;
    });
  }

  /* =====================================================
     NOMINATIM
     ===================================================== */
  async function nominatimSearch(query, limit) {
    // Rate limit: 1 request per ~1.1s
    const wait = NOMINATIM_COOLDOWN_MS - (Date.now() - state.lastNominatimAt);
    if (wait > 0) {
      await new Promise((r) => setTimeout(r, wait));
    }
    state.lastNominatimAt = Date.now();

    const url =
      `${NOMINATIM_BASE}/search?format=json&addressdetails=1` +
      `&limit=${limit || 5}&email=cybertrace-demo%40example.com` +
      `&q=${encodeURIComponent(query)}`;

    const response = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      throw new Error('Geocoding service unavailable (' + response.status + ')');
    }
    return response.json();
  }

  function normalizeNominatimResult(result) {
    const addr = result.address || {};
    const name =
      result.name ||
      addr.city ||
      addr.town ||
      addr.village ||
      addr.county ||
      (result.display_name && result.display_name.split(',')[0]) ||
      'Unknown';
    return {
      id: result.place_id || uid('place'),
      name: name,
      address: result.display_name || '',
      lat: parseFloat(result.lat),
      lng: parseFloat(result.lon),
      type: result.type || result.class || 'Place',
      country: addr.country || '',
      region: addr.state || addr.region || ''
    };
  }

  async function performSearch(query, limit) {
    const trimmed = (query || '').trim();
    if (!trimmed) throw new Error('Please enter a location name.');
    const results = await nominatimSearch(trimmed, limit || 5);
    if (!Array.isArray(results) || results.length === 0) {
      return { query: trimmed, results: [] };
    }
    return { query: trimmed, results: results.map(normalizeNominatimResult) };
  }

  /* =====================================================
     WIKIMEDIA IMAGES
     ===================================================== */
  async function fetchWikimediaImages(placeName, country) {
    const searchTerm = [placeName, country].filter(Boolean).join(' ');
    const params = new URLSearchParams({
      action: 'query',
      generator: 'search',
      gsrsearch: searchTerm,
      gsrnamespace: '6',
      gsrlimit: '8',
      prop: 'imageinfo',
      iiprop: 'url|extmetadata',
      iiurlwidth: '300',
      format: 'json',
      origin: '*'
    });

    const response = await fetch(`${WIKIMEDIA_COMMONS_API}?${params.toString()}`);
    if (!response.ok) throw new Error('Image service unavailable');
    const data = await response.json();
    if (!data.query || !data.query.pages) return [];

    const items = [];
    for (const key in data.query.pages) {
      const page = data.query.pages[key];
      const info = page.imageinfo && page.imageinfo[0];
      if (!info) continue;
      const thumbUrl = info.thumburl || info.url;
      if (!thumbUrl) continue;
      const meta = info.extmetadata || {};
      items.push({
        title: (page.title || '').replace(/^File:/, ''),
        description: meta.ImageDescription && meta.ImageDescription.value,
        author: meta.Artist && meta.Artist.value,
        license:
          (meta.LicenseShortName && meta.LicenseShortName.value) || '',
        pageUrl:
          'https://commons.wikimedia.org/wiki/' +
          encodeURIComponent(page.title || ''),
        thumbUrl: thumbUrl
      });
    }
    return items;
  }

  function renderImageGallery(container, images) {
    if (!container) return;
    container.innerHTML = '';

    if (!images || images.length === 0) {
      container.innerHTML =
        '<div class="empty-state">No relevant photographs found for this location.</div>';
      return;
    }

    images.forEach((img) => {
      const item = document.createElement('div');
      item.className = 'gallery-item';
      item.tabIndex = 0;
      item.setAttribute('role', 'button');
      item.setAttribute('aria-label', 'Open image source: ' + img.title);

      const image = document.createElement('img');
      image.src = img.thumbUrl;
      image.alt = img.title || 'Location photograph';
      image.loading = 'lazy';

      const label = document.createElement('p');
      label.textContent = truncate(img.title, 40);
      label.title = img.title;

      item.appendChild(image);
      item.appendChild(label);

      const openSource = () => {
        if (img.pageUrl) window.open(img.pageUrl, '_blank', 'noopener');
      };
      item.addEventListener('click', openSource);
      item.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openSource();
        }
      });

      container.appendChild(item);
    });
  }

  /* =====================================================
     LOCATION DETAILS
     ===================================================== */
  function renderLocationDetails(container, location) {
    if (!container) return;
    if (!location) {
      container.innerHTML = '<div class="empty-state">No location selected.</div>';
      return;
    }
    const tags = [];
    if (location.type) tags.push(location.type);
    if (location.country) tags.push(location.country);
    if (location.region) tags.push(location.region);
    if (location.lat != null && location.lng != null) {
      tags.push(
        `${safeNum(location.lat).toFixed(4)}, ${safeNum(location.lng).toFixed(4)}`
      );
    }

    container.innerHTML = `
      <div class="location-meta">
        <div class="location-name">
          <i class="fas fa-location-dot"></i> ${escapeHTML(location.name || 'Unknown')}
        </div>
        <div class="location-addr">${escapeHTML(location.address || 'Address unavailable')}</div>
        <div class="location-tags">
          ${tags.map((t) => `<span class="tag">${escapeHTML(t)}</span>`).join('')}
        </div>
      </div>
    `;
  }

  /* =====================================================
     SEARCH HISTORY
     ===================================================== */
  function addSearchHistory(query) {
    if (!query) return;
    let history = getHistory();
    history = history.filter(
      (h) => h.query.toLowerCase() !== query.toLowerCase()
    );
    history.unshift({ query, at: nowISO() });
    if (history.length > 25) history = history.slice(0, 25);
    setHistory(history);
  }

  function renderSearchHistory(listEl, full) {
    if (!listEl) return;
    const history = getHistory();
    if (history.length === 0) {
      listEl.innerHTML = '<li class="empty-state">No recent searches</li>';
      return;
    }
    const items = full ? history : history.slice(0, 8);
    listEl.innerHTML = items
      .map(
        (h) =>
          `<li data-query="${escapeHTML(h.query)}" title="${escapeHTML(
            formatDateTime(h.at)
          )}"><i class="fas fa-circle"></i> ${escapeHTML(h.query)}</li>`
      )
      .join('');
  }

  function renderFullSearchHistory() {
    const list = qs('#fullSearchHistory');
    if (!list) return;
    const history = getHistory();
    if (history.length === 0) {
      list.innerHTML = '<li class="empty-state">No searches yet.</li>';
      return;
    }
    list.innerHTML = history
      .map(
        (h) =>
          `<li data-query="${escapeHTML(h.query)}"><i class="fas fa-circle"></i> ${escapeHTML(
            h.query
          )}<small>${formatDateTime(h.at)}</small></li>`
      )
      .join('');
  }

  function renderGeoSearchHistory() {
    renderSearchHistory(qs('#geoSearchHistory'), false);
  }

  /* =====================================================
     CASES
     ===================================================== */
  function createCase(input) {
    const cases = getCases();
    const newCase = {
      id: uid('CT'),
      title: input.title || 'Untitled Case',
      objective: input.objective || '',
      targetLocation: input.targetLocation || '',
      status: input.status || 'Open',
      createdAt: nowISO(),
      updatedAt: nowISO(),
      notes: input.notes || '',
      locations: input.locations || [],
      evidenceIds: input.evidenceIds || [],
      searchQueries: input.searchQueries || []
    };
    cases.unshift(newCase);
    setCases(cases);
    refreshStats();
    renderCaseLists();
    return newCase;
  }

  function updateCase(id, patch) {
    const cases = getCases();
    const idx = cases.findIndex((c) => c.id === id);
    if (idx === -1) return null;
    cases[idx] = { ...cases[idx], ...patch, updatedAt: nowISO() };
    setCases(cases);
    refreshStats();
    renderCaseLists();
    return cases[idx];
  }

  function deleteCase(id) {
    const cases = getCases().filter((c) => c.id !== id);
    setCases(cases);
    const ev = getEvidence().map((e) =>
      e.caseId === id ? { ...e, caseId: '' } : e
    );
    setEvidence(ev);
    refreshStats();
    renderCaseLists();
    renderEvidenceList();
  }

  function getCaseById(id) {
    return getCases().find((c) => c.id === id) || null;
  }

  function statusClass(status) {
    return (status || 'Open').toLowerCase().replace(/\s+/g, '');
  }

  function renderDashboardCases() {
    const container = qs('#dashboardCaseList');
    if (!container) return;
    const cases = getCases();
    if (cases.length === 0) {
      container.innerHTML = '<div class="empty-state">No cases yet.</div>';
      return;
    }
    container.innerHTML = '';
    cases.slice(0, 4).forEach((c) => {
      const item = document.createElement('div');
      item.className = 'case-item';
      item.tabIndex = 0;
      item.innerHTML = `
        <div>
          <div class="case-item-title">${escapeHTML(c.title)}</div>
          <small>${escapeHTML(c.id)} · ${formatDateTime(c.updatedAt)}</small>
        </div>
        <span class="status-badge ${statusClass(c.status)}">${escapeHTML(c.status)}</span>
      `;
      item.addEventListener('click', () => showCaseDetail(c.id));
      item.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') showCaseDetail(c.id);
      });
      container.appendChild(item);
    });
  }

  function renderFullCases() {
    const container = qs('#casesFullList');
    if (!container) return;
    const cases = getCases();
    if (cases.length === 0) {
      container.innerHTML =
        '<div class="empty-state">No cases yet. Create one to get started.</div>';
      return;
    }
    container.innerHTML = '';
    cases.forEach((c) => {
      const item = document.createElement('div');
      item.className = 'case-item';
      item.tabIndex = 0;
      item.innerHTML = `
        <div>
          <div class="case-item-title">${escapeHTML(c.title)}</div>
          <small>${escapeHTML(c.id)} · Objective: ${escapeHTML(
        truncate(c.objective || '—', 60)
      )} · ${formatDateTime(c.updatedAt)}</small>
        </div>
        <span class="status-badge ${statusClass(c.status)}">${escapeHTML(c.status)}</span>
      `;
      item.addEventListener('click', () => showCaseDetail(c.id));
      item.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') showCaseDetail(c.id);
      });
      container.appendChild(item);
    });
  }

  function renderCaseLists() {
    renderDashboardCases();
    renderFullCases();
    renderCaseSelects();
  }

  function renderCaseSelects() {
    const cases = getCases();
    const selects = [qs('#evCase'), qs('#reportCaseSelect')];
    selects.forEach((sel) => {
      if (!sel) return;
      const current = sel.value;
      const placeholder =
        sel.id === 'reportCaseSelect' ? '— Select case —' : '— None —';
      sel.innerHTML =
        `<option value="">${placeholder}</option>` +
        cases
          .map(
            (c) =>
              `<option value="${escapeHTML(c.id)}">${escapeHTML(
                c.id + ' · ' + c.title
              )}</option>`
          )
          .join('');
      if (current && cases.some((c) => c.id === current)) sel.value = current;
    });
  }

  function showCaseDetail(id) {
    const c = getCaseById(id);
    const card = qs('#caseDetailCard');
    const container = qs('#caseDetailContainer');
    if (!c || !card || !container) return;

    switchView('cases');

    const evidence = getEvidence().filter((e) => e.caseId === c.id);
    const locations = c.locations || [];

    container.innerHTML = `
      <div class="case-detail-block">
        <h4>Case Information</h4>
        <p><strong>ID:</strong> ${escapeHTML(c.id)}</p>
        <p><strong>Title:</strong> ${escapeHTML(c.title)}</p>
        <p><strong>Objective:</strong> ${escapeHTML(c.objective || '—')}</p>
        <p><strong>Target Location:</strong> ${escapeHTML(c.targetLocation || '—')}</p>
        <p><strong>Status:</strong> <span class="status-badge ${statusClass(c.status)}">${escapeHTML(c.status)}</span></p>
        <p class="meta">Created: ${formatDateTime(c.createdAt)} · Updated: ${formatDateTime(c.updatedAt)}</p>
      </div>

      <div class="case-detail-block">
        <h4>Notes</h4>
        <p>${escapeHTML(c.notes || 'No notes recorded.')}</p>
      </div>

      <div class="case-detail-block">
        <h4>Attached Locations (${locations.length})</h4>
        ${
          locations.length === 0
            ? '<p class="meta">No locations attached.</p>'
            : locations
                .map(
                  (loc) => `
              <p>
                <strong>${escapeHTML(loc.name || 'Unknown')}</strong><br>
                <span class="meta">${escapeHTML(loc.address || '')}</span><br>
                <span class="meta">${safeNum(loc.lat).toFixed(5)}, ${safeNum(
                    loc.lng
                  ).toFixed(5)} · ${escapeHTML(loc.type || '')}</span>
              </p>`
                )
                .join('')
        }
      </div>

      <div class="case-detail-block">
        <h4>Evidence References (${evidence.length})</h4>
        ${
          evidence.length === 0
            ? '<p class="meta">No evidence references.</p>'
            : evidence
                .map(
                  (e) => `
              <p>
                <strong>${escapeHTML(e.title)}</strong><br>
                <span class="meta">${escapeHTML(e.description || '')}</span><br>
                <span class="meta">${escapeHTML(e.url || '')}</span><br>
                <span class="meta">Collected: ${formatDateTime(e.collectedAt)}</span>
              </p>`
                )
                .join('')
        }
      </div>

      <div class="card-actions">
        <button class="btn-cyan" id="editCaseStatusBtn"><i class="fas fa-pen"></i> Change Status</button>
        <button class="btn-outline" id="exportCaseBtn"><i class="fas fa-download"></i> Export JSON</button>
        <button class="btn-danger" id="deleteCaseBtn"><i class="fas fa-trash"></i> Delete Case</button>
      </div>
    `;

    card.style.display = 'block';

    qs('#editCaseStatusBtn').addEventListener('click', () => {
      const statuses = ['Open', 'In Progress', 'Closed'];
      const next = statuses[(statuses.indexOf(c.status) + 1) % statuses.length];
      updateCase(c.id, { status: next });
      showCaseDetail(c.id);
      toast('Case status set to ' + next, 'success');
    });

    qs('#deleteCaseBtn').addEventListener('click', () => {
      if (confirm('Delete case ' + c.id + '? This cannot be undone.')) {
        deleteCase(c.id);
        card.style.display = 'none';
        container.innerHTML = '';
        toast('Case deleted', 'success');
      }
    });

    qs('#exportCaseBtn').addEventListener('click', () => {
      const payload = {
        case: c,
        evidence: evidence,
        exportedAt: nowISO(),
        disclaimer:
          'Publicly available information may be incomplete or outdated and must be independently verified.'
      };
      downloadFile(
        JSON.stringify(payload, null, 2),
        c.id + '.json',
        'application/json'
      );
    });
  }

  /* =====================================================
     EVIDENCE
     ===================================================== */
  function renderEvidenceList() {
    const container = qs('#evidenceList');
    if (!container) return;
    const evidence = getEvidence();
    if (evidence.length === 0) {
      container.innerHTML =
        '<div class="empty-state">No evidence records yet.</div>';
      return;
    }
    container.innerHTML = '';
    evidence
      .slice()
      .sort((a, b) => (b.collectedAt || '').localeCompare(a.collectedAt || ''))
      .forEach((e) => {
        const caseObj = getCaseById(e.caseId);
        const row = document.createElement('div');
        row.className = 'evidence-row';
        row.innerHTML = `
          <div class="evidence-row-info">
            <div class="evidence-row-title">${escapeHTML(e.title)}</div>
            <div class="evidence-row-meta">${escapeHTML(e.description || '')}</div>
            <div class="evidence-row-meta">
              ${caseObj ? 'Case: ' + escapeHTML(caseObj.id) + ' · ' : ''}
              ${e.collectedAt ? 'Collected: ' + formatDateTime(e.collectedAt) : ''}
            </div>
            ${
              e.url
                ? `<div class="evidence-row-meta">Source: <a href="${escapeHTML(
                    e.url
                  )}" target="_blank" rel="noopener" style="color:var(--blush)">${escapeHTML(
                    truncate(e.url, 60)
                  )}</a></div>`
                : ''
            }
            <div class="evidence-row-meta" style="color:var(--text-dim)">
              <i class="fas fa-user-pen"></i> Investigator-provided record
            </div>
          </div>
          <div class="evidence-row-actions">
            <button class="btn-outline" data-action="edit" data-id="${escapeHTML(e.id)}" title="Edit"><i class="fas fa-pen"></i></button>
            <button class="btn-outline" data-action="delete" data-id="${escapeHTML(e.id)}" title="Delete"><i class="fas fa-trash"></i></button>
          </div>
        `;
        container.appendChild(row);
      });

    container.querySelectorAll('[data-action="delete"]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        if (confirm('Delete this evidence record?')) {
          setEvidence(getEvidence().filter((x) => x.id !== id));
          renderEvidenceList();
          refreshStats();
          toast('Evidence deleted', 'success');
        }
      });
    });

    container.querySelectorAll('[data-action="edit"]').forEach((btn) => {
      btn.addEventListener('click', () => editEvidence(btn.getAttribute('data-id')));
    });
  }

  function editEvidence(id) {
    const list = getEvidence();
    const e = list.find((x) => x.id === id);
    if (!e) return;
    const newTitle = prompt('Evidence title:', e.title);
    if (newTitle === null) return;
    const newDesc = prompt('Description:', e.description || '');
    if (newDesc === null) return;
    const newUrl = prompt('Source URL:', e.url || '');
    if (newUrl === null) return;
    const newNotes = prompt('Investigator notes:', e.notes || '');
    if (newNotes === null) return;
    e.title = newTitle;
    e.description = newDesc;
    e.url = newUrl;
    e.notes = newNotes;
    setEvidence(list);
    renderEvidenceList();
    toast('Evidence updated', 'success');
  }

  /* =====================================================
     STATS
     ===================================================== */
  function refreshStats() {
    const cases = getCases();
    const evidence = getEvidence();
    const locations = getSavedLocations();
    const openCount = cases.filter((c) => c.status === 'Open').length;

    const setText = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    setText('statCases', cases.length);
    setText('statOpen', openCount);
    setText('statLocations', locations.length);
    setText('statEvidence', evidence.length);
    setText('topStatCases', cases.length);
    setText('topStatLocations', locations.length);
    setText('topStatEvidence', evidence.length);
  }

  /* =====================================================
     SAVED LOCATIONS
     ===================================================== */
  function saveLocationToCase(location, caseId) {
    if (!location) return;

    const saved = getSavedLocations();
    saved.unshift({ ...location, savedAt: nowISO(), caseId: caseId || '' });
    setSavedLocations(saved);

    if (caseId) {
      const c = getCaseById(caseId);
      if (c) {
        const locs = (c.locations || []).concat({
          name: location.name,
          address: location.address,
          lat: location.lat,
          lng: location.lng,
          type: location.type,
          country: location.country,
          region: location.region,
          savedAt: nowISO()
        });
        updateCase(caseId, { locations: locs });
      }
    }

    refreshStats();
    toast('Location saved' + (caseId ? ' to case' : ''), 'success');
  }

  function renderSavedLocations() {
    const container = qs('#savedLocationsList');
    if (!container) return;
    const saved = getSavedLocations();
    if (saved.length === 0) {
      container.innerHTML = '<div class="empty-state">No saved locations.</div>';
      return;
    }
    container.innerHTML = saved
      .map(
        (l) => `
      <div class="case-detail-block">
        <p><strong>${escapeHTML(l.name || 'Unknown')}</strong></p>
        <p class="meta">${escapeHTML(l.address || '')}</p>
        <p class="meta">${safeNum(l.lat).toFixed(5)}, ${safeNum(l.lng).toFixed(
          5
        )} · ${escapeHTML(l.type || '')} · Saved ${formatDateTime(l.savedAt)}</p>
      </div>`
      )
      .join('');
  }

  /* =====================================================
     REPORT
     ===================================================== */
  function buildReportText(caseId) {
    const c = getCaseById(caseId);
    if (!c) return null;
    const evidence = getEvidence().filter((e) => e.caseId === caseId);

    const lines = [];
    lines.push('CYBERTRACE — INVESTIGATION REPORT');
    lines.push('Project by: Syeda Zoya');
    lines.push('=================================');
    lines.push('');
    lines.push('Case ID: ' + c.id);
    lines.push('Title: ' + (c.title || '—'));
    lines.push('Status: ' + c.status);
    lines.push('Created: ' + formatDateTime(c.createdAt));
    lines.push('Updated: ' + formatDateTime(c.updatedAt));
    lines.push('');
    lines.push('OBJECTIVE');
    lines.push('---------');
    lines.push(c.objective || '—');
    lines.push('');
    lines.push('TARGET LOCATION');
    lines.push('---------------');
    lines.push(c.targetLocation || '—');
    lines.push('');
    lines.push('INVESTIGATOR NOTES');
    lines.push('------------------');
    lines.push(c.notes || '—');
    lines.push('');
    lines.push('SEARCH QUERIES');
    lines.push('--------------');
    if (c.searchQueries && c.searchQueries.length) {
      c.searchQueries.forEach((q) => lines.push('- ' + q));
    } else {
      lines.push('—');
    }
    lines.push('');
    lines.push('ATTACHED LOCATIONS');
    lines.push('------------------');
    if (c.locations && c.locations.length) {
      c.locations.forEach((loc, i) => {
        lines.push(
          `${i + 1}. ${loc.name} — ${safeNum(loc.lat).toFixed(5)}, ${safeNum(
            loc.lng
          ).toFixed(5)}`
        );
        lines.push('   ' + (loc.address || ''));
        lines.push(
          '   Google Maps: https://www.google.com/maps?q=' + loc.lat + ',' + loc.lng
        );
      });
    } else {
      lines.push('—');
    }
    lines.push('');
    lines.push('EVIDENCE REFERENCES');
    lines.push('-------------------');
    if (evidence.length) {
      evidence.forEach((e, i) => {
        lines.push(`${i + 1}. ${e.title}`);
        lines.push('   ' + (e.description || ''));
        lines.push('   Source: ' + (e.url || '—'));
        lines.push('   Collected: ' + formatDateTime(e.collectedAt));
        if (e.notes) lines.push('   Notes: ' + e.notes);
      });
    } else {
      lines.push('—');
    }
    lines.push('');
    lines.push('DATA SOURCES');
    lines.push('------------');
    lines.push('- OpenStreetMap (map tiles & geocoding)');
    lines.push('- Nominatim (geocoding API)');
    lines.push('- Wikimedia Commons (photographs)');
    lines.push('');
    lines.push('LIMITATIONS & VERIFICATION STATUS');
    lines.push('---------------------------------');
    lines.push(
      'Publicly available information may be incomplete or outdated and must be independently verified.'
    );
    lines.push(
      'This report does not constitute proof that any person, device, or suspect was present at the described location.'
    );
    lines.push(
      'Investigator-provided evidence has not been cryptographically verified.'
    );
    lines.push('');
    lines.push('Report generated: ' + formatDateTime(nowISO()));

    return lines.join('\n');
  }

  function renderReportPreview(caseId) {
    const container = qs('#reportPreview');
    if (!container) return;
    if (!caseId) {
      container.innerHTML =
        '<div class="empty-state">Select a case to generate a report.</div>';
      return;
    }
    const text = buildReportText(caseId);
    if (!text) {
      container.innerHTML = '<div class="empty-state">Case not found.</div>';
      return;
    }
    container.textContent = text;
  }

  /* =====================================================
     DOWNLOAD
     ===================================================== */
  function downloadFile(content, filename, mime) {
    const blob = new Blob([content], { type: mime || 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  /* =====================================================
     VIEW SWITCHING
     ===================================================== */
  function switchView(viewName) {
    state.activeView = viewName;
    qsa('.view').forEach((v) => v.classList.remove('active'));
    const target = qs('#view-' + viewName);
    if (target) target.classList.add('active');

    qsa('.nav-item').forEach((n) => {
      n.classList.toggle('active', n.dataset.view === viewName);
    });

    setTimeout(() => {
      state.dashboardMap && state.dashboardMap.invalidateSize();
      state.geospatialMap && state.geospatialMap.invalidateSize();
      state.fullMap && state.fullMap.invalidateSize();
    }, 60);

    if (viewName === 'history') {
      renderFullSearchHistory();
      renderSavedLocations();
    }
    if (viewName === 'report') {
      renderCaseSelects();
    }
    if (viewName === 'evidence') {
      renderEvidenceList();
    }
    if (viewName === 'cases') {
      renderFullCases();
    }
    if (viewName === 'gallery') {
      renderGalleryView();
    }
  }

  function renderGalleryView() {
    const container = qs('#imageGalleryFull');
    if (!container) return;
    if (!state.currentLocation) {
      container.innerHTML =
        '<div class="empty-state">Search a location to load images.</div>';
      return;
    }
    container.innerHTML =
      '<div class="empty-state"><span class="loading-spinner"></span> Loading images…</div>';
    fetchWikimediaImages(state.currentLocation.name, state.currentLocation.country)
      .then((imgs) => renderImageGallery(container, imgs))
      .catch(() => {
        container.innerHTML =
          '<div class="empty-state">Unable to load images.</div>';
      });
  }

  /* =====================================================
     SEARCH FLOWS
     ===================================================== */
  async function handleDashboardSearch(query) {
    const btn = qs('#globalSearchBtn');
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<span class="loading-spinner"></span>';
    }
    try {
      const res = await performSearch(query, 1);
      if (res.results.length === 0) {
        toast('Location not found. Try another query.', 'error');
        return;
      }
      const loc = res.results[0];
      state.currentLocation = loc;
      updateMapMarker(loc);
      renderLocationDetails(qs('#locationDetailsContainer'), loc);
      addSearchHistory(res.query);
      renderSearchHistory(qs('#searchHistoryList'));
      renderFullSearchHistory();
      toast('Location found: ' + loc.name, 'success');

      const gallery = qs('#imageGallery');
      if (gallery) {
        gallery.innerHTML =
          '<div class="empty-state"><span class="loading-spinner"></span> Loading images…</div>';
        try {
          const images = await fetchWikimediaImages(loc.name, loc.country);
          renderImageGallery(gallery, images);
        } catch {
          gallery.innerHTML =
            '<div class="empty-state">Unable to load images.</div>';
        }
      }
    } catch (err) {
      console.error(err);
      toast(err.message || 'Search failed.', 'error');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Search';
      }
    }
  }

  async function handleGeospatialSearch(query) {
    const btn = qs('#geospatialSearchBtn');
    const statusEl = qs('#searchStatus');
    const suggestionsEl = qs('#searchSuggestions');

    if (!query || !query.trim()) {
      if (statusEl)
        statusEl.innerHTML =
          '<span style="color:var(--red)">Please enter a location.</span>';
      return;
    }

    state.searchInProgress = true;
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<span class="loading-spinner"></span>';
    }
    if (statusEl) statusEl.textContent = 'Searching…';
    if (suggestionsEl) suggestionsEl.innerHTML = '';

    try {
      const res = await performSearch(query, 5);
      state.searchResults = res.results;
      state.lastSearchQuery = res.query;

      addSearchHistory(res.query);
      renderSearchHistory(qs('#searchHistoryList'));
      renderGeoSearchHistory();

      if (res.results.length === 0) {
        if (statusEl)
          statusEl.innerHTML =
            '<span style="color:var(--red)">No locations found. Try a different query.</span>';
        toast('No results found.', 'error');
        return;
      }

      if (statusEl)
        statusEl.innerHTML = `<span style="color:var(--green)">${res.results.length} result(s) found.</span>`;

      if (res.results.length > 1 && suggestionsEl) {
        suggestionsEl.innerHTML = '';
        res.results.forEach((r) => {
          const item = document.createElement('button');
          item.className = 'suggestion-item';
          item.type = 'button';
          item.innerHTML = `<strong>${escapeHTML(r.name)}</strong><small>${escapeHTML(
            truncate(r.address, 90)
          )}</small>`;
          item.addEventListener('click', () => selectGeospatialResult(r));
          suggestionsEl.appendChild(item);
        });
      }

      selectGeospatialResult(res.results[0], true);
    } catch (err) {
      console.error(err);
      if (statusEl)
        statusEl.innerHTML = `<span style="color:var(--red)">${escapeHTML(
          err.message || 'Search failed.'
        )}</span>`;
      toast(err.message || 'Search failed.', 'error');
    } finally {
      state.searchInProgress = false;
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Search';
      }
    }
  }

  async function selectGeospatialResult(result, silent) {
    state.currentLocation = result;
    updateMapMarker(result);
    renderLocationDetails(qs('#geoDetailsContainer'), result);
    if (!silent) toast('Selected: ' + result.name, 'success');

    const gallery = qs('#imageGalleryGeo');
    if (gallery) {
      gallery.innerHTML =
        '<div class="empty-state"><span class="loading-spinner"></span> Loading images…</div>';
      try {
        const images = await fetchWikimediaImages(result.name, result.country);
        renderImageGallery(gallery, images);
      } catch {
        gallery.innerHTML =
          '<div class="empty-state">Unable to load images.</div>';
      }
    }
  }

  /* =====================================================
     COORDS / GOOGLE MAPS
     ===================================================== */
  function copyCoords(location) {
    if (!location || location.lat == null) {
      toast('No location selected.', 'error');
      return;
    }
    const text = location.lat + ', ' + location.lng;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(text)
        .then(() => toast('Coordinates copied: ' + text, 'success'))
        .catch(() => toast('Copy failed.', 'error'));
    } else {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
        toast('Coordinates copied: ' + text, 'success');
      } catch {
        toast('Copy failed.', 'error');
      }
      document.body.removeChild(ta);
    }
  }

  function openGoogleMaps(location) {
    if (!location || location.lat == null) {
      toast('No location selected.', 'error');
      return;
    }
    window.open(
      'https://www.google.com/maps?q=' + location.lat + ',' + location.lng,
      '_blank',
      'noopener'
    );
  }

  /* =====================================================
     EVENT BINDING
     ===================================================== */
  function bindEvents() {
    // Navigation
    qsa('.nav-item').forEach((btn) => {
      btn.addEventListener('click', () => switchView(btn.dataset.view));
    });

    // Dashboard search
    qs('#globalSearchBtn').addEventListener('click', () => {
      handleDashboardSearch(qs('#globalSearchInput').value);
    });
    qs('#globalSearchInput').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') handleDashboardSearch(qs('#globalSearchInput').value);
    });

    // Geospatial search
    qs('#geospatialSearchBtn').addEventListener('click', () => {
      handleGeospatialSearch(qs('#geospatialSearchInput').value);
    });
    qs('#geospatialSearchInput').addEventListener('keydown', (e) => {
      if (e.key === 'Enter')
        handleGeospatialSearch(qs('#geospatialSearchInput').value);
    });
    qs('#clearSearchBtn').addEventListener('click', () => {
      qs('#geospatialSearchInput').value = '';
      qs('#searchSuggestions').innerHTML = '';
      qs('#searchStatus').textContent = '';
      state.searchResults = [];
      state.lastSearchQuery = '';
    });

    // Copy / Maps (dashboard, geo, full)
    qs('#copyCoordsBtn').addEventListener('click', () => copyCoords(state.currentLocation));
    qs('#openGoogleMapsBtn').addEventListener('click', () => openGoogleMaps(state.currentLocation));
    qs('#copyCoordsBtnGeo').addEventListener('click', () => copyCoords(state.currentLocation));
    qs('#openGoogleMapsBtnGeo').addEventListener('click', () => openGoogleMaps(state.currentLocation));
    qs('#copyCoordsBtnFull').addEventListener('click', () => copyCoords(state.currentLocation));
    qs('#openGoogleMapsBtnFull').addEventListener('click', () => openGoogleMaps(state.currentLocation));

    // Save to case
    qs('#saveLocationBtn').addEventListener('click', () => promptSaveLocation(false));
    qs('#attachToCaseBtn').addEventListener('click', () => promptSaveLocation(true));

    // New case buttons
    qs('#newCaseBtn').addEventListener('click', openNewCaseDialog);
    qs('#newCaseBtn2').addEventListener('click', openNewCaseDialog);
    qs('#viewAllCasesBtn').addEventListener('click', () => switchView('cases'));

    // Evidence form
    const evForm = qs('#evidenceForm');
    evForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const title = qs('#evTitle').value.trim();
      if (!title) {
        toast('Evidence title is required.', 'error');
        return;
      }
      const evidence = getEvidence();
      const dateVal = qs('#evDate').value;
      evidence.unshift({
        id: uid('EV'),
        title: title,
        description: qs('#evDescription').value.trim(),
        url: qs('#evUrl').value.trim(),
        caseId: qs('#evCase').value,
        collectedAt: dateVal ? new Date(dateVal).toISOString() : nowISO(),
        notes: qs('#evNotes').value.trim(),
        location: qs('#evLocation').value.trim(),
        createdAt: nowISO()
      });
      setEvidence(evidence);
      evForm.reset();
      const now = new Date();
      now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
      qs('#evDate').value = now.toISOString().slice(0, 16);
      renderEvidenceList();
      refreshStats();
      toast('Evidence record saved.', 'success');
    });

    // Report controls
    qs('#reportCaseSelect').addEventListener('change', (e) =>
      renderReportPreview(e.target.value)
    );
    qs('#printReportBtn').addEventListener('click', () => {
      const id = qs('#reportCaseSelect').value;
      if (!id) return toast('Select a case first.', 'error');
      renderReportPreview(id);
      setTimeout(() => window.print(), 100);
    });
    qs('#downloadJsonBtn').addEventListener('click', () => {
      const id = qs('#reportCaseSelect').value;
      if (!id) return toast('Select a case first.', 'error');
      const c = getCaseById(id);
      const evidence = getEvidence().filter((e) => e.caseId === id);
      const payload = {
        case: c,
        evidence: evidence,
        generatedAt: nowISO(),
        dataSources: ['OpenStreetMap', 'Nominatim', 'Wikimedia Commons'],
        disclaimer:
          'Publicly available information may be incomplete or outdated and must be independently verified. This report does not constitute proof that any person, device, or suspect was present at the described location.'
      };
      downloadFile(JSON.stringify(payload, null, 2), c.id + '-report.json', 'application/json');
    });
    qs('#downloadTxtBtn').addEventListener('click', () => {
      const id = qs('#reportCaseSelect').value;
      if (!id) return toast('Select a case first.', 'error');
      const text = buildReportText(id);
      if (text) downloadFile(text, id + '-report.txt', 'text/plain');
    });

    // Clear all data
    qs('#clearAllDataBtn').addEventListener('click', () => {
      if (
        confirm(
          'Clear ALL local data (cases, evidence, history, saved locations)? This cannot be undone.'
        )
      ) {
        Object.values(STORAGE).forEach((k) => localStorage.removeItem(k));
        refreshStats();
        renderCaseLists();
        renderEvidenceList();
        renderSearchHistory(qs('#searchHistoryList'));
        renderFullSearchHistory();
        renderGeoSearchHistory();
        renderSavedLocations();
        qs('#caseDetailCard').style.display = 'none';
        qs('#caseDetailContainer').innerHTML = '';
        qs('#reportPreview').innerHTML =
          '<div class="empty-state">Select a case to generate a report.</div>';
        toast('All local data cleared.', 'success');
      }
    });

    // Fullscreen map (both buttons)
    const toggleFullscreen = () => {
      const mapEl = document.querySelector('.view.active #map, .view.active #mapFull');
      if (!mapEl) return;
      if (!document.fullscreenElement) {
        mapEl.requestFullscreen && mapEl.requestFullscreen().catch(() => {});
      } else {
        document.exitFullscreen && document.exitFullscreen();
      }
    };
    qs('#fullscreenMapBtn').addEventListener('click', toggleFullscreen);
    qs('#fullscreenMapBtn2').addEventListener('click', toggleFullscreen);
    document.addEventListener('fullscreenchange', () => {
      setTimeout(() => {
        state.dashboardMap && state.dashboardMap.invalidateSize();
        state.geospatialMap && state.geospatialMap.invalidateSize();
        state.fullMap && state.fullMap.invalidateSize();
      }, 200);
    });

    // History click (delegated, works in all views)
    document.addEventListener('click', (e) => {
      const li = e.target.closest('li[data-query]');
      if (!li) return;
      const query = li.getAttribute('data-query');
      if (!query) return;
      const input = qs('#globalSearchInput');
      if (input) input.value = query;
      switchView('dashboard');
      handleDashboardSearch(query);
    });

    // Debounced suggestions for geospatial input
    qs('#geospatialSearchInput').addEventListener(
      'input',
      debounce(async (e) => {
        if (state.searchInProgress) return;
        const q = e.target.value.trim();
        const suggestionsEl = qs('#searchSuggestions');
        if (!suggestionsEl) return;
        if (q.length < 3) {
          suggestionsEl.innerHTML = '';
          return;
        }
        try {
          const results = await nominatimSearch(q, 5);
          if (!results || results.length === 0) {
            suggestionsEl.innerHTML = '';
            return;
          }
          if (state.searchInProgress) return;
          suggestionsEl.innerHTML = '';
          results.forEach((r) => {
            const norm = normalizeNominatimResult(r);
            const item = document.createElement('button');
            item.type = 'button';
            item.className = 'suggestion-item';
            item.innerHTML = `<strong>${escapeHTML(norm.name)}</strong><small>${escapeHTML(
              truncate(norm.address, 90)
            )}</small>`;
            item.addEventListener('click', () => {
              qs('#geospatialSearchInput').value = norm.name;
              suggestionsEl.innerHTML = '';
              selectGeospatialResult(norm);
              addSearchHistory(norm.name);
              renderGeoSearchHistory();
            });
            suggestionsEl.appendChild(item);
          });
        } catch (err) {
          console.warn('Suggestion fetch failed', err);
        }
      }, 600)
    );

    // Escape clears suggestions
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const s = qs('#searchSuggestions');
        if (s) s.innerHTML = '';
      }
    });
  }

  function promptSaveLocation(onlyExisting) {
    if (!state.currentLocation) {
      toast('Search and select a location first.', 'error');
      return;
    }
    const cases = getCases();
    if (cases.length === 0) {
      if (onlyExisting) {
        toast('No cases available. Create a case first.', 'error');
        return;
      }
      if (confirm('No cases exist. Create a new case to save this location?')) {
        const title = prompt(
          'Case title:',
          'Location: ' + state.currentLocation.name
        );
        if (!title) return;
        const c = createCase({
          title: title,
          targetLocation: state.currentLocation.name,
          objective: 'Investigating ' + state.currentLocation.name
        });
        saveLocationToCase(state.currentLocation, c.id);
      }
      return;
    }
    const list = cases.map((c, i) => `${i + 1}. ${c.id} — ${c.title}`).join('\n');
    const choice = prompt(
      'Select a case number (or leave empty to save globally):\n' + list
    );
    if (choice === null) return;
    if (choice.trim() === '') {
      if (onlyExisting) {
        toast('Please choose a case number.', 'error');
        return;
      }
      saveLocationToCase(state.currentLocation, null);
      return;
    }
    const idx = parseInt(choice, 10) - 1;
    if (isNaN(idx) || idx < 0 || idx >= cases.length) {
      toast('Invalid case number.', 'error');
      return;
    }
    saveLocationToCase(state.currentLocation, cases[idx].id);
  }

  function openNewCaseDialog() {
    const title = prompt('Case title:', 'New Investigation');
    if (!title) return;
    const objective = prompt(
      'Investigation objective:',
      'Geospatial verification of location'
    );
    const target = prompt(
      'Target location name (optional):',
      state.currentLocation ? state.currentLocation.name : ''
    );
    const c = createCase({
      title: title,
      objective: objective || '',
      targetLocation: target || '',
      status: 'Open'
    });
    toast('Case created: ' + c.id, 'success');
    showCaseDetail(c.id);
  }

  /* =====================================================
     INIT
     ===================================================== */
  function init() {
    initMaps();
    bindEvents();

    refreshStats();
    renderCaseLists();
    renderEvidenceList();
    renderSearchHistory(qs('#searchHistoryList'));
    renderGeoSearchHistory();
    renderFullSearchHistory();
    renderSavedLocations();

    // Default evidence datetime
    const evDate = qs('#evDate');
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    evDate.value = now.toISOString().slice(0, 16);

    switchView('dashboard');

    console.info(
      'CyberTrace ready (Project by Syeda Zoya). All investigation data is stored locally in this browser.'
    );
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();